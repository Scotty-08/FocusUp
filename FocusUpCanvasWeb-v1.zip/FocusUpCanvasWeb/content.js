// Only ever runs on an origin the user explicitly granted -- registered
// dynamically by background.js, never declared as a static content
// script in manifest.json, so it never touches any other site.
//
// Deliberately thin: the actual Canvas fetch + Supabase push lives in
// background.js. This just pings it every time the page loads;
// background.js applies its own throttle, so pinging on every load is
// cheap and safe.
(async () => {
    try {
        await chrome.runtime.sendMessage({ type: "syncOrigin", origin: location.origin });
    } catch (error) {
        console.log("FocusUp auto-sync skipped:", error);
    }
})();
